#include "Energy.h"
#include <iostream>
#include <stdio.h>
#define fr 138.935485
#define krf 0.289 
#define crf 1.25

void Energy::
reinit (const ValueType rup_,
	const ValueType x0_,
	const ValueType x1_)
{
  rup = rup_;
  x0 = x0_;
  x1 = x1_;
  if (x0 > x1) {
    ValueType tmpx = x0;
    x0 = x1;
    x1 = tmpx;
  }  
  energy = 0.;
  nframe = 0.;
  natom = 0.;
}


ValueType RFL(const ValueType q1, const ValueType q2, const ValueType eps, const ValueType sig, const ValueType dist, const int beads)
{
ValueType vdw, coul, ener, sSq, dSq, val;
dSq = dist*dist;
sSq = sig*sig;
val = (sSq/dSq)*(sSq/dSq)*(sSq/dSq);
vdw = 4.0*eps*(val*val - val);
val = fr*q1*q2;
coul = val*(1/sqrt( dSq ) + krf*dSq - crf);
ener = coul + vdw;
return ener;
}


ValueType RF(const ValueType q1, const ValueType q2, const ValueType dist, const int beads)
{
ValueType val, coul, dSq;
val = fr*q1*q2;
dSq = dist*dist;
coul = val*(1/sqrt( dSq ) + krf*dSq - crf);
return coul;
}

ValueType anglecalc(ValueType a, ValueType b, ValueType c)
{
ValueType rad = acos((a*a + b*b - c*c)/(2*a*b));
return rad;
}

void Energy::
deposit (const std::vector<std::vector<ValueType> > & coord,
	 const VectorType & box,
	 const CellList & clist, const ValueType q1, const ValueType q2, 
         const ValueType eps, const ValueType sig, const int beads, 
         const ValueType bondconst, const ValueType bondequil, const ValueType angleconst, 
         const ValueType angleequil, const int nmolecules)
{
  int xiter = rup / clist.getCellSize().x;
  if (xiter * clist.getCellSize().x < rup) xiter ++;
  int yiter = rup / clist.getCellSize().y;
  if (yiter * clist.getCellSize().y < rup) yiter ++;
  int ziter = rup / clist.getCellSize().z;
  if (ziter * clist.getCellSize().z < rup) ziter ++;
  int index1, index2, mol1, mol2, atom1, atom2;
  IntVectorType nCell = clist.getNumCell();
  ValueType myNatom = 0.;
  ValueType Evdwcoul, kino, kinh;
  VectorType OW, HW1, HW2;
  ValueType rad, angle, bond;
 /* for (unsigned i = 0; i < nmolecules; i++)
   {
      OW.x = vel[i*3][0];
      OW.y = vel[i*3][1];
      OW.z = vel[i*3][2];
      HW1.x = vel[i*3 + 1][0];
      HW1.y = vel[i*3 + 1][1];
      HW1.z = vel[i*3 + 1][2]; 
      HW2.x = vel[i*3 + 2][0];
      HW2.y = vel[i*3 + 2][1];
      HW2.z = vel[i*3 + 2][2];
      if ((!(OW.x >= x0 && OW.x < x1))) continue;
      kino = 0.5 * 16.0 * (OW.x*OW.x + OW.y*OW.y + OW.z*OW.z);
      kinh = 0.5 * 1.0 * (HW1.x * HW1.x + HW1.y * HW1.y + HW1.z * HW1.z + HW2.x * HW2.x + HW2.y * HW2.y + HW2.z * HW2.z);
      energy += (kino + kinh);
      if ((!(OW.x >= x0 && OW.x < x1))) continue;
      VectorType diff1, diff2, diff3;
      diff1.x = -OW.x + HW1.x; 
      diff1.y = -OW.y + HW1.y;
      diff1.z = -OW.z + HW1.z;
      diff2.x = -OW.x + HW2.x;
      diff2.y = -OW.y + HW2.y;
      diff2.z = -OW.z + HW2.z;
      diff3.x = -HW1.x + HW2.x;
      diff3.y = -HW1.y + HW2.y;
      diff3.z = -HW1.z + HW2.z;
      if      (diff1.x < -.5 * box.x) diff1.x += box.x;
      else if (diff1.x >= .5 * box.x) diff1.x -= box.x;
      if      (diff1.y < -.5 * box.y) diff1.y += box.y;
      else if (diff1.y >= .5 * box.y) diff1.y -= box.y;
      if      (diff1.z < -.5 * box.z) diff1.z += box.z;
      else if (diff1.z >= .5 * box.z) diff1.z -= box.z;
      ValueType dr1 = diff1.x * diff1.x + diff1.y * diff1.y + diff1.z * diff1.z;
      dr1 = sqrt(dr1);
      if      (diff2.x < -.5 * box.x) diff2.x += box.x;
      else if (diff2.x >= .5 * box.x) diff2.x -= box.x;
      if      (diff2.y < -.5 * box.y) diff2.y += box.y;
      else if (diff2.y >= .5 * box.y) diff2.y -= box.y;
      if      (diff2.z < -.5 * box.z) diff2.z += box.z;
      else if (diff2.z >= .5 * box.z) diff2.z -= box.z;
      ValueType dr2 = diff2.x * diff2.x + diff2.y * diff2.y + diff2.z * diff2.z;
      dr2 = sqrt(dr2);
      bond = 0.5*bondconst*(dr1-bondequil)*(dr1-bondequil) + 0.5*bondconst*(dr2-bondequil)*(dr2-bondequil);   
      if      (diff3.x < -.5 * box.x) diff3.x += box.x;
      else if (diff3.x >= .5 * box.x) diff3.x -= box.x;
      if      (diff3.y < -.5 * box.y) diff3.y += box.y;
      else if (diff3.y >= .5 * box.y) diff3.y -= box.y;
      if      (diff3.z < -.5 * box.z) diff3.z += box.z;
      else if (diff3.z >= .5 * box.z) diff3.z -= box.z;
      ValueType dr3 = diff3.x * diff3.x + diff3.y * diff3.y + diff3.z * diff3.z;
      dr3 = sqrt(dr3);
      rad = anglecalc(dr1, dr2, dr3); 
      angle = 0.5*angleconst*(rad - angleequil)*(rad - angleequil);            
      energy += (angle + bond);
    }*/

  for (unsigned iCellIndex = 0;
       iCellIndex < unsigned(nCell.x * nCell.y * nCell.z);
       ++iCellIndex){
    std::vector<unsigned > neighborCellIndex =
	clist.neighboringCellIndex (iCellIndex, IntVectorType (xiter, yiter, ziter));
    for (unsigned iNeighborCellIndex = 0;
	 iNeighborCellIndex < neighborCellIndex.size();
	 ++iNeighborCellIndex){
      unsigned jCellIndex = neighborCellIndex[iNeighborCellIndex];
      for (unsigned ii = 0; ii < clist.getList()[iCellIndex].size(); ++ii){
	VectorType icoord;
	icoord.x = coord[clist.getList()[iCellIndex][ii]][0];
	if (x1 != 0. && (!(icoord.x >= x0 && icoord.x < x1))) continue;
	if (iNeighborCellIndex == 0) myNatom += 1.;
	icoord.y = coord[clist.getList()[iCellIndex][ii]][1];
	icoord.z = coord[clist.getList()[iCellIndex][ii]][2];
	bool sameCell (iCellIndex == jCellIndex);
	for (unsigned jj = 0; jj < clist.getList()[jCellIndex].size(); ++jj){
	  if (sameCell && ii == jj) continue;
          index1 = clist.getList()[iCellIndex][ii]; 
          index2 = clist.getList()[jCellIndex][jj];
          mol1 = index1/3;
          mol2 = index2/3;
	  if (mol1 == mol2) continue;  
          atom1 = index1%3;
          atom2 = index2%3;
	  VectorType jcoord;
	  jcoord.x = coord[clist.getList()[jCellIndex][jj]][0];
	  jcoord.y = coord[clist.getList()[jCellIndex][jj]][1];
	  jcoord.z = coord[clist.getList()[jCellIndex][jj]][2];
          if (x1 != 0. && (!(jcoord.x >= x0 && jcoord.x < x1))) continue;
	  VectorType diff;
	  diff.x = - icoord.x + jcoord.x;
	  diff.y = - icoord.y + jcoord.y;
	  diff.z = - icoord.z + jcoord.z;
	 // if      (diff.x < -.5 * box.x) diff.x += box.x;
	 // else if (diff.x >= .5 * box.x) diff.x -= box.x;
	  if      (diff.y < -.5 * box.y) diff.y += box.y;
	  else if (diff.y >= .5 * box.y) diff.y -= box.y;
	  if      (diff.z < -.5 * box.z) diff.z += box.z;
	  else if (diff.z >= .5 * box.z) diff.z -= box.z;
	  ValueType dr = diff.x * diff.x + diff.y * diff.y + diff.z * diff.z;
  	  dr = sqrt(dr);
          if (dr < rup)
          {    
               Evdwcoul = 0.0;
               if (atom1 == 0 and atom2 == 0)
                  Evdwcoul = RFL(q1, q1, eps, sig, dr, beads);
               if ((atom1 == 0 and atom2 == 1) or (atom1 == 1 and atom2 == 0))
                  Evdwcoul = RF(q1, q2, dr, beads);
               if ((atom1 == 0 and atom2 == 2) or (atom1 == 2 and atom2 == 0)) 
                  Evdwcoul = RF(q1, q2, dr, beads);
               if (atom1 == 1 and atom2 == 1)
                  Evdwcoul = RF(q2, q2, dr, beads);
               if ((atom1 == 1 and atom2 == 2) or (atom1 == 2 and atom2 == 1))
                  Evdwcoul = RF(q2, q2, dr, beads); 
               if (atom1 == 2 and atom2 == 2)
                  Evdwcoul = RF(q2, q2, dr, beads);
               energy += Evdwcoul/2;
        }
       }
      }
    }
  }

}
