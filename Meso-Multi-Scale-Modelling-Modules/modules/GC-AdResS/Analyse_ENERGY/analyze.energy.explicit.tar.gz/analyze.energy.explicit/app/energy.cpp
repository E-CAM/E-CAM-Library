#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <queue>
#include <vector>
#include <cmath>

#include "xdrfile/xdrfile.h"
#include "xdrfile/xdrfile_xtc.h"
#include "BlockAverage.h"
#include <boost/program_options.hpp>
namespace po = boost::program_options;
#include "Energy.h"

int main(int argc, char * argv[])
{
  ValueType begin, end, rup, cellSize;
  std::string ifile, ofile, method;
  ValueType x0, x1, q1, q2, sig, eps, bondconst, bondequil, angleconst, angleequil;
  int numBlock;
  int beads; 
  po::options_description desc ("Allow options");
  desc.add_options()
      ("help,h", "print this message")
      ("begin,b", po::value<ValueType > (&begin)->default_value(0.f), "start time")
      ("end,e",   po::value<ValueType > (&end  )->default_value(0.f), "end   time")
      ("nblock,n", po::value<int > (&numBlock)->default_value(16), "number of blocks")
      ("x0", po::value<ValueType > (&x0)->default_value(0.f), "lower bound of the interval")
      ("x1", po::value<ValueType > (&x1)->default_value(1.f), "upper bound of the interval, if x1 == 0, use the whole box")
      ("q1", po::value<ValueType > (&q1)->default_value(0.f), "charge on oxygen")
      ("q2", po::value<ValueType > (&q2)->default_value(0.f), "charge on hydrogen")
      ("sig", po::value<ValueType > (&sig)->default_value(0.f), "sigma")
      ("eps", po::value<ValueType > (&eps)->default_value(0.f), "eps")
      ("bondconst", po::value<ValueType > (&bondconst)->default_value(0.f), "bond constant")
      ("bondequil", po::value<ValueType > (&bondequil)->default_value(0.f), "bond equilibrium distance")
      ("angleconst", po::value<ValueType > (&angleconst)->default_value(0.f), "angle constant")
      ("angleequil", po::value<ValueType > (&angleequil)->default_value(0.f), "angle equilibrium distance")
      ("rup,u",   po::value<ValueType > (&rup)->default_value(3.f), "max r to make rdf")
      ("beads", po::value<int > (&beads)->default_value(16), "no. of beads in one ring polymer")
      ("cell-size,c", po::value<ValueType > (&cellSize)->default_value(1.f), "cell list radius")
      ("method,m",  po::value<std::string > (&method)->default_value ("adress"), "type of simulation to analyze")
      ("input,f",   po::value<std::string > (&ifile)->default_value ("traj.xtc"), "the input .xtc file")
      ("output,o",  po::value<std::string > (&ofile)->default_value ("energy.out"), "the output file");
       
  po::variables_map vm;
  po::store(po::parse_command_line(argc, argv, desc), vm);
  po::notify (vm);
  if (vm.count("help")){
    std::cout << desc<< "\n";
    return 0;
  }

  if (x0 > x1) {
    ValueType tmpx = x0;
    x0 = x1;
    x1 = tmpx;
  }  
  
  std::cout << "###################################################" << std::endl;
  std::cout << "# begin->end: " << begin << " " << end << std::endl;
  std::cout << "# [x0,  x1 ]: " << x0 << " " << x1 << std::endl;
  std::cout << "# rup: " << rup << std::endl;
  std::cout << "# method: " << method << std::endl;
  std::cout << "# input: " << ifile << std::endl;
  std::cout << "# number of blocks: " << numBlock << std::endl;
  std::cout << "###################################################" << std::endl;  
  
  XDRFILE *fp;
  int natoms, step;
  float time, lambda;
  float prec = 1000.;
  matrix box;
  rvec *xx, *vv, *ff;
  float time_prec = .01;
  std::vector<double> totalenergy;
  char tmpfname[1024];
  strncpy (tmpfname, ifile.c_str(), 1023);
  int c;
  if ((c = read_xtc_natoms (tmpfname, &natoms)) == 0) {
    // printf ("%d %d\n", c, natoms);
    xx = (rvec *) malloc (sizeof(rvec) * natoms);
    vv = (rvec *) malloc (sizeof(rvec) * natoms);
    ff = (rvec *) malloc (sizeof(rvec) * natoms);
  }
  else {
    // printf ("%d %d\n", c, natoms);
    fprintf (stderr, "error read_xtc_natoms");
    exit (1);
  }

  fp = xdrfile_open (ifile.c_str(), "r");
  if (fp == NULL){
    std::cerr << "cannot open file " << ifile << std::endl;
    exit (1);
  }
  if (read_xtc (fp, natoms, &step, &time, box, xx, &prec) != 0) {
    std::cerr << "error reading file " << ifile << std::endl;
    return 1;
  }
  
  int nmolecules = 0;
  if (method == std::string("adress")){
    nmolecules = natoms / 4;
  }
  else if (method == std::string("atom")){
    nmolecules = natoms / 3;
  }
  else {
    std::cerr << "wrong method" << std::endl;
    return 1;
  }

  VectorType vbox;
  vbox.x = box[0][0];
  vbox.y = box[1][1];
  vbox.z = box[2][2];
  if (cellSize >= .5 * vbox.x){
    std::cerr << "the cell size should be less than half of the box size" << std::endl;
    return 1;
  }
 
  std::vector<std::vector<ValueType > > coms;
  coms.reserve (nmolecules*3);
  std::vector<std::vector<ValueType > > coms1;
  coms1.reserve (nmolecules*3);

  Energy myenergy;
  FILE *fout = fopen (ofile.c_str(), "w");
  if (fout == NULL){
      std::cerr << "cannot open file " << ofile << std::endl;
      exit (1);
     }
  
  int countread = 0;
  while (read_xtc (fp, natoms, &step, &time, box, xx, &prec) == 0){
    if (end != 0.f) {
      if (time < begin - time_prec){
	continue;
      }
      else if (time > end + time_prec) {
	break;
      }	
    }
    else {
      if (time < begin - time_prec) continue;
    }
    if (countread++ % 1 == 0){
      printf ("# load frame at time: %.1f ps\r", time);
      fflush (stdout);
    }
    
    int atomPerMol = 1;
    if (method == std::string ("adress")){
      atomPerMol = 4;
    }
    else if (method == std::string ("atom")){
      atomPerMol = 3;
    }
    
    myenergy.reinit (rup, x0, x1);
    CellList clist (nmolecules, vbox, cellSize);
    coms.clear();
    coms1.clear();
    for (int j = 0; j < nmolecules; j++) 
              {
              if      (xx[atomPerMol*j][0] <  0        ) xx[atomPerMol*j][0] += box[0][0];
              else if (xx[atomPerMol*j][0] >= box[0][0]) xx[atomPerMol*j][0] -= box[0][0];
              if      (xx[atomPerMol*j][1] <  0        ) xx[atomPerMol*j][1] += box[1][1];
              else if (xx[atomPerMol*j][1] >= box[1][1]) xx[atomPerMol*j][1] -= box[1][1];
              if      (xx[atomPerMol*j][2] <  0        ) xx[atomPerMol*j][2] += box[2][2];
              else if (xx[atomPerMol*j][2] >= box[2][2]) xx[atomPerMol*j][2] -= box[2][2];
              if      (xx[atomPerMol*j + 1][0] <  0        ) xx[atomPerMol*j + 1][0] += box[0][0];
              else if (xx[atomPerMol*j + 1][0] >= box[0][0]) xx[atomPerMol*j + 1][0] -= box[0][0];
              if      (xx[atomPerMol*j + 1][1] <  0        ) xx[atomPerMol*j + 1][1] += box[1][1];
              else if (xx[atomPerMol*j + 1][1] >= box[1][1]) xx[atomPerMol*j + 1][1] -= box[1][1];
              if      (xx[atomPerMol*j + 1][2] <  0        ) xx[atomPerMol*j + 1][2] += box[2][2];
              else if (xx[atomPerMol*j + 1][2] >= box[2][2]) xx[atomPerMol*j + 1][2] -= box[2][2];
              if      (xx[atomPerMol*j + 2][0] <  0        ) xx[atomPerMol*j + 2][0] += box[0][0];
              else if (xx[atomPerMol*j + 2][0] >= box[0][0]) xx[atomPerMol*j + 2][0] -= box[0][0];
              if      (xx[atomPerMol*j + 2][1] <  0        ) xx[atomPerMol*j + 2][1] += box[1][1];
              else if (xx[atomPerMol*j + 2][1] >= box[1][1]) xx[atomPerMol*j + 2][1] -= box[1][1];
              if      (xx[atomPerMol*j + 2][2] <  0        ) xx[atomPerMol*j + 2][2] += box[2][2];
              else if (xx[atomPerMol*j + 2][2] >= box[2][2]) xx[atomPerMol*j + 2][2] -= box[2][2];
              std::vector<ValueType > tmpo(3);
              std::vector<ValueType > tmph1(3);
              std::vector<ValueType > tmph2(3);
              tmpo[0] = xx[atomPerMol*j][0];
              tmpo[1] = xx[atomPerMol*j][1];
              tmpo[2] = xx[atomPerMol*j][2];
              coms.push_back(tmpo);
              tmph1[0] = xx[atomPerMol*j + 1][0];
              tmph1[1] = xx[atomPerMol*j + 1][1];
              tmph1[2] = xx[atomPerMol*j + 1][2];
              coms.push_back(tmph1);
              tmph2[0] = xx[atomPerMol*j + 2][0];
              tmph2[1] = xx[atomPerMol*j + 2][1];
              tmph2[2] = xx[atomPerMol*j + 2][2];
              coms.push_back(tmph2);
              }
     clist.rebuild(coms);     
     myenergy.deposit (coms, vbox, clist, q1, q2, eps, sig, beads, bondconst, bondequil, angleconst, angleequil, nmolecules);  
     totalenergy.push_back(myenergy.getValue());    
   std::cout << time << "  " << totalenergy[countread-1] << " " << "\n";
   fprintf(fout, "%f %f \n", time, myenergy.getValue());
   } 
  xdrfile_close (fp);
  free (xx);
  fclose (fout);
  return 0;
}
