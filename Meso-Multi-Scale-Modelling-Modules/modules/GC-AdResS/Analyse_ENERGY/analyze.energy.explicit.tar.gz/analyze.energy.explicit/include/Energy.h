#ifndef __Rdf_h_wanghan__
#define __Rdf_h_wanghan__

#include "Defines.h"
#include "CellList.h"

class Energy 
{
  ValueType rup;
  ValueType offset;
  int nframe;
  ValueType natom;
  ValueType x0, x1;
  ValueType energy;
public:
  ValueType getValue() {return energy;}
  void reinit (const ValueType rup,
	       const ValueType x0 = 0.,
	       const ValueType x1 = 0.);
  void deposit (const std::vector<std::vector<ValueType> > & coord,
 		const VectorType & box,
		const CellList & clist,
                const ValueType q1, 
                const ValueType q2, 
                const ValueType eps, 
                const ValueType sig, 
                const int beads, 
                const ValueType bondconst, 
                const ValueType bondequil, 
                const ValueType angleconst, 
                const ValueType angleequil,
                const int nmolecules);
  void calculate (const int beads);
}
    ;


#endif
